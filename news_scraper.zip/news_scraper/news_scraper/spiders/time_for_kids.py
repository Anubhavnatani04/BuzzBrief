import scrapy
from datetime import datetime  # added import
from news_scraper.items import NewsScraperItem  # added import

class TimeForKidsSpider(scrapy.Spider):
    name = "time_for_kids"
    allowed_domains = ["timeforkids.com"]
    start_urls = [
        "https://www.timeforkids.com/g34/",
        "https://www.timeforkids.com/k1/",
        "https://www.timeforkids.com/g2/",
        "https://www.timeforkids.com/g56/"
    ]
    page_count = 1  # added page_count attribute

    def parse(self, response):
        # Extract article links from the main page
        article_links = response.css("article a::attr(href)").getall()  # updated article selector
        for link in article_links:
            yield response.follow(link, callback=self.parse_article)
        
        # Handle pagination if exists
        next_page = response.css("a.next::attr(href)").get()  # updated pagination selector
        if next_page and self.page_count < 10:
            self.page_count += 1
            yield response.follow(next_page, callback=self.parse)

    def parse_article(self, response):
        item = NewsScraperItem()
        item["id"] = 7
        item["title"] = response.css("h1.article-title::text").get(default="").strip()
        item["image_url"] = response.css("div.article-image img::attr(src)").get()
        item["content"] = " ".join(response.css("div.article-content p::text").getall())
        item["source"] = "Time for Kids"
        item["url"] = response.url
        item["published_at"] = response.css("time::attr(datetime)").get()
        item["is_kid_friendly"] = True
        item["created_at"] = datetime.now()
        item["categories"] = response.css("div.article-categories a::text").getall()
        yield item
