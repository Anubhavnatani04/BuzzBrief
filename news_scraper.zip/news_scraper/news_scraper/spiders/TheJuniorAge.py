import scrapy


class ThejuniorageSpider(scrapy.Spider):
    name = "TheJuniorAge"
    allowed_domains = ["thejuniorage.com"]
    start_urls = ["https://thejuniorage.com/articles/"]

    def parse(self, response):
        pass
